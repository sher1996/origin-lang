# Greeter Package

A simple greeting package for Origin Language.

## Usage

```origin
import "greeter"
```

This will print a friendly greeting message.

## Version

Current version: 0.2.0 